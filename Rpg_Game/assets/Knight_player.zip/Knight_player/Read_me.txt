Twitter @Jump_Button

Size 100x64

Speed is up to you go with what feels right but for landing on ground make it fast
If there is anything that you want to add and I feel it would be useful for others, let me know and I will try and add the animation.


License Permissions:

You can do:

- You can use this asset for personal and commercial purposes. Credit is not required for personal use but is required for any commercial use. 

- Modify to suit your needs.

You can't do or use for:

Do not resell or reproduce the image for profit.

Do NOT use any of my work for AI (artificial intelligence technology, Machine Learning technology, or any derived technologies, AI/ML Training) NFT, blockchain technology, cryptocurrency, bitcoin, or any platforms or purposes that create products using this technology in any form (AI creation or NFTs). Such usage is completely prohibited and may result in legal action if necessary.